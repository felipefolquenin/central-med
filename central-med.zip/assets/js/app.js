/* Central Med — render e navegação
   por Felipe Folquenin */
(function () {
  "use strict";

  var MESES = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  var DIAS = ["domingo", "segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado"];

  function parse(s) { var p = s.split("-"); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function fmt(dt) { return pad(dt.getDate()) + "/" + pad(dt.getMonth() + 1); }
  function pad(n) { return String(n).padStart(2, "0"); }
  function el(id) { return document.getElementById(id); }
  function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

  var hoje = new Date(); hoje.setHours(0, 0, 0, 0);

  /* ---------- armazenamento local, sempre protegido ---------- */
  var LS = (function () { try { return window.localStorage; } catch (e) { return null; } })();
  function get(k) { try { return LS ? LS.getItem(k) : null; } catch (e) { return null; } }
  function set(k, v) { try { if (LS) LS.setItem(k, v); } catch (e) {} }

  /* =================== SEMESTRE =================== */

  /* grade da semana */
  var wk = el("week");
  GRADE.forEach(function (g) {
    var d = document.createElement("div");
    var isToday = hoje.getDay() === g.n;
    d.className = "day" + (isToday ? " today" : "");
    var h = '<div class="dayhead"><span>' + g.d + "</span>" + (isToday ? "<em>HOJE</em>" : "") + "</div>";
    g.aulas.forEach(function (a) {
      h += '<div class="slot' + (a.night ? " night" : "") + (a.lab ? " lab" : "") + '">' +
        '<span class="t">' + a.t + '</span><span class="n">' + esc(a.n) +
        "<small>" + a.t + "–" + a.f + " · " + esc(a.s) + "</small></span></div>";
    });
    d.innerHTML = h;
    wk.appendChild(d);
  });

  /* disciplinas */
  var dc = el("discs");
  DISC.forEach(function (d, i) {
    var art = document.createElement("article");
    art.className = "disc";
    var h = "<header><div><h3>" + esc(d.n) + '</h3><p class="prof">' + esc(d.p) + "</p></div>" +
      '<span class="pill ' + d.tag + '">' + esc(d.tagt) + "</span></header>";
    h += "<dl><dt>Quando</dt><dd>" + esc(d.q) + "</dd>" +
      (d.livro !== "—" ? "<dt>Base</dt><dd>" + esc(d.livro) + "</dd>" : "") + "</dl>";
    if (d.files.length) {
      h += '<ul class="files">' + d.files.map(function (f) { return "<li>" + esc(f) + "</li>"; }).join("") + "</ul>";
    }
    if (d.ck.length) {
      h += '<ul class="checks">' + d.ck.map(function (c, j) {
        return '<li><label><input type="checkbox" data-k="ck' + i + "-" + j + '"><span>' + esc(c) + "</span></label></li>";
      }).join("") + "</ul>";
    }
    art.innerHTML = h;
    dc.appendChild(art);
  });

  /* checkboxes persistentes */
  Array.prototype.forEach.call(document.querySelectorAll(".checks input"), function (inp) {
    var k = "centralmed-" + inp.dataset.k;
    if (get(k) === "1") inp.checked = true;
    inp.addEventListener("change", function () { set(k, inp.checked ? "1" : "0"); });
  });

  /* calendário do semestre */
  var tl = el("tl"), achouProx = false, proxProva = null;
  CAL.forEach(function (c) {
    var dt = parse(c.d), past = dt < hoje, li = document.createElement("li");
    var cls = (c.exam ? "exam " : "") + (past ? "past" : "");
    if (!past && !achouProx) { cls += " next"; achouProx = true; }
    if (!past && c.exam && !proxProva) proxProva = c;
    li.className = cls.trim();
    li.innerHTML = '<div class="d">' + fmt(dt) + " · " + DIAS[dt.getDay()].slice(0, 3) + "</div>" +
      '<p class="h">' + esc(c.h) + "</p>" + (c.s ? '<p class="s">' + esc(c.s) + "</p>" : "");
    tl.appendChild(li);
  });

  /* tiles do semestre */
  if (proxProva) {
    var pd = parse(proxProva.d), dias = Math.round((pd - hoje) / 864e5);
    el("prova-nome").textContent = proxProva.h.replace(/^PROVA — /, "").replace(/^EXAME final — /, "Exame final: ");
    el("prova-quando").textContent = (dias === 0 ? "É hoje" : dias === 1 ? "É amanhã" : "Em " + dias + " dias") +
      " · " + fmt(pd) + ", " + DIAS[pd.getDay()];
  } else {
    el("t-prova").classList.remove("alarm");
    el("prova-nome").textContent = "Nenhuma";
    el("prova-quando").textContent = "Semestre encerrado.";
  }

  el("hoje-data").textContent = DIAS[hoje.getDay()].replace("-feira", "");
  var gh = GRADE.filter(function (g) { return g.n === hoje.getDay(); })[0];
  el("hoje-aulas").textContent = gh
    ? gh.aulas.map(function (a) { return a.t + " " + a.n; }).join(" · ")
    : "Sem aula na grade.";

  var ini = parse(SEMESTRE.inicio), fim = parse(SEMESTRE.fim);
  var pct = Math.max(0, Math.min(100, Math.round((hoje - ini) / (fim - ini) * 100)));
  el("sem-pct").textContent = pct + "%";
  el("sem-bar").style.width = pct + "%";
  var faltam = Math.max(0, Math.round((fim - hoje) / 864e5));
  el("sem-txt").textContent = "percorrido · faltam " + faltam + " dias até o encerramento do 2º bimestre";

  el("gaps").innerHTML = GAPS.map(function (g) { return "<li>" + g + "</li>"; }).join("");

  /* =================== CARREIRA =================== */

  var FORMATURA = parse("2031-12-15");
  var PRIMEIRA_PROVA = parse("2031-09-13");

  function anos(ate) { return (ate - hoje) / 3.15576e10; }

  el("c-formatura").textContent = "dez/2031";
  el("c-formatura-txt").textContent = "faltam " + anos(FORMATURA).toFixed(1).replace(".", ",") + " anos · 6 anos de curso";
  el("c-prova").textContent = "set/2031";
  el("c-prova-txt").textContent = "ENAMED, obrigatório para todo formando · nota vale 3 anos";

  /* Fase atual = o último marco que já começou. Uma fase só vira "passada"
     quando a seguinte começa — senão o 2º período apareceria apagado hoje. */
  var iAtual = 0;
  ROTA.forEach(function (f, i) { if (parse(f.d) <= hoje) iAtual = i; });
  el("c-fase").textContent = ROTA[iAtual].h;
  el("c-fase-txt").textContent = ROTA[iAtual].ano;

  /* linha do tempo da rota */
  var rtl = el("rota-tl");
  ROTA.forEach(function (f, i) {
    var li = document.createElement("li");
    var cls = (f.key ? "key " : "") + (i < iAtual ? "past" : "") + (i === iAtual ? " next" : "");
    li.className = cls.trim();
    li.innerHTML = '<div class="d">' + esc(f.ano) + "</div>" +
      '<p class="h">' + esc(f.h) + "</p>" +
      '<p class="s">' + esc(f.s) + "</p>";
    rtl.appendChild(li);
  });

  /* critérios */
  el("crit").innerHTML = CRITERIOS.map(function (c, i) {
    return '<li><span class="n">' + pad(i + 1) + "</span><div><h4>" + esc(c.h) + "</h4><p>" + esc(c.p) + "</p></div></li>";
  }).join("");

  /* serviços */
  el("servicos-box").innerHTML = SERVICOS.map(function (bloco) {
    var head = "<tr>" + bloco.cols.map(function (c) { return "<th>" + esc(c) + "</th>"; }).join("") + "</tr>";
    var body = bloco.linhas.map(function (l) {
      return "<tr>" + l.map(function (v, i) {
        var conteudo = v === "sim" ? '<span class="tag">sim</span>'
          : v === "não" ? '<span class="tag no">não</span>'
          : i === 0 ? "<b>" + esc(v) + "</b>" : esc(v);
        return '<td data-label="' + esc(bloco.cols[i]) + '">' + conteudo + "</td>";
      }).join("") + "</tr>";
    }).join("");
    return '<p class="cap">' + esc(bloco.cenario) + "</p>" +
      '<p style="font-size:14px;color:var(--ink-2);margin:0 0 10px">' + esc(bloco.nota) + "</p>" +
      '<div class="tblwrap"><table><thead>' + head + "</thead><tbody>" + body + "</tbody></table></div>";
  }).join("");

  /* calendário de provas */
  el("provas-tbl").querySelector("tbody").innerHTML = PROVAS.map(function (p) {
    return "<tr>" +
      '<td data-label="Prova"><b>' + esc(p.n) + "</b></td>" +
      '<td data-label="Abrangência">' + esc(p.a) + "</td>" +
      '<td data-label="Inscrição" class="num">' + esc(p.i) + "</td>" +
      '<td data-label="Prova" class="num">' + esc(p.p) + "</td></tr>";
  }).join("");

  /* ações por fase */
  el("acoes-box").innerHTML = ACOES.map(function (a) {
    return '<article class="disc"><header><div><h3>' + esc(a.h) + "</h3></div>" +
      '<span class="pill ' + a.tag + '">' + esc(a.tagt) + "</span></header>" +
      '<ul class="plain">' + a.itens.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + "</ul></article>";
  }).join("");

  /* fontes de provas antigas */
  el("fontes-box").innerHTML = FONTES.map(function (f) {
    return "<li><b>" + esc(f.n) + "</b><span>" + esc(f.s) + "</span>" +
      (f.u ? '<br><a href="' + f.u + '" target="_blank" rel="noopener">' + f.u + "</a>" : "") + "</li>";
  }).join("");

  /* =================== NAVEGAÇÃO =================== */

  var CHIPS = {
    semestre: [["#agora", "Agora"], ["#grade", "Grade da semana"], ["#disciplinas", "Disciplinas"], ["#calendario", "Calendário"], ["#pendencias", "O que falta"]],
    carreira: [["#rota", "Resumo"], ["#linha", "A rota"], ["#criterios", "Critérios"], ["#servicos", "Serviços"], ["#provas", "Provas"], ["#acoes", "O que fazer"], ["#fontes", "Provas antigas"]]
  };
  var TITULOS = {
    semestre: { t: "Central do 2º Período", e: "Medicina · Uniguairacá · 2º período · Turma A · 2026/2" },
    carreira: { t: "Rota até a cirurgia plástica", e: "Residência · cirurgia geral como pré-requisito · 2031–2036" }
  };

  function trocarView(v) {
    if (!CHIPS[v]) v = "semestre";
    el("view-semestre").hidden = v !== "semestre";
    el("view-carreira").hidden = v !== "carreira";
    Array.prototype.forEach.call(document.querySelectorAll(".segbtn"), function (b) {
      b.setAttribute("aria-selected", b.dataset.view === v ? "true" : "false");
    });
    el("chips").innerHTML = CHIPS[v].map(function (c) {
      return '<a href="' + c[0] + '">' + c[1] + "</a>";
    }).join("");
    el("apptitle").textContent = TITULOS[v].t;
    el("eyebrow").textContent = TITULOS[v].e;
    set("centralmed-view", v);
    if (location.hash.slice(2) !== v) history.replaceState(null, "", "#/" + v);
    window.scrollTo(0, 0);
  }

  Array.prototype.forEach.call(document.querySelectorAll(".segbtn"), function (b) {
    b.addEventListener("click", function () { trocarView(b.dataset.view); });
  });

  var inicial = location.hash.indexOf("#/") === 0 ? location.hash.slice(2) : (get("centralmed-view") || "semestre");
  trocarView(inicial);

  /* tema */
  var temaSalvo = get("centralmed-tema");
  if (temaSalvo) document.documentElement.setAttribute("data-theme", temaSalvo);
  el("theme").addEventListener("click", function () {
    var r = document.documentElement, cur = r.getAttribute("data-theme");
    var escuroAgora = cur ? cur === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
    var novo = escuroAgora ? "light" : "dark";
    r.setAttribute("data-theme", novo);
    set("centralmed-tema", novo);
  });

  /* rodapé */
  el("stamp").textContent = "aberto em " + fmt(new Date()) + "/" + new Date().getFullYear();

  /* service worker — deixa o app abrir offline */
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("sw.js").catch(function () {});
    });
  }
})();
